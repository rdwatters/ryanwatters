#Resources

####My URLS 

* [http://www.linkedin.com/pub/ryan-watters-els/25/107/80](http://www.linkedin.com/pub/ryan-watters-els/25/107/80)
* [Disqus id=3685429](https://www.disqus.com) The following includes disqus shortcode to allow for total comments. 
* Pinterest: https://www.pinterest.com/ryandwatters/
* Google +: https://plus.google.com/u/0/116346973477086026124/posts/p/pub

```html

<div id="disqus_thread"></div>
<script type="text/javascript">
    /* * * CONFIGURATION VARIABLES * * */
    var disqus_shortname = 'ryanwattersme';
    
    /* * * DON'T EDIT BELOW THIS LINE * * */
    (function() {
        var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
        dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
        (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>

```
* Twitter Button:

```html
<a href="https://twitter.com/share" class="twitter-share-button" data-dnt="true">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
```

* Twitter Timeline for My Account:
```html
<a class="twitter-timeline" data-dnt="true" data-link-color="#cc0000" href="https://twitter.com/ryandwatters" height="350px" width="350px" data-widget-id="592894823012634624" data-tweet-limit="5" aria-polite="polite">Tweets by @ryandwatters</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>


```
* Social Media Colors:
    - FaceBook Blue: #3b5998
    - Twitter Blue: #00aced
    - Google+ Red: #dd4b39
    - YouTube Red: #bb0000
    - LinkedIn Blue: #007bb6
    - Instagram Blue: #517fa4
    - Pinterest Red: #cb2027
    - Vine Green: #00bf8f
    - Tumblr Dark Turquoise: #32506D
    - Vimeo Green: #aad450
    - Quora Burgundy: #a82400
* HealthyChildren Typography & Colors
    - Headings: Arvo
    - Heading weight: 400
    - Heading color: #564d39
    - "read more" button: #f9b964 (primary button color?)
    - "read more" button on hover: #e85325 
    - "go" button home page: #E9B424 (secondary button color?)
 
##Topics -> Keywords:

* Publishing
    - Content Strategy
    - Editorial
    - Content Management Systems (CMS) 
* Web Technologies
    - HTML5
    - Accessibility
    - CSS3
    - Javascript
    - User Experience
    - Performance
* Essays
    - Politics
    - Humor
    - Philosophy

##Document Categories:

* Article
* Blog
* Tutorial

##APIs:

* FaceBook Javascript API - [https://developers.facebook.com/docs/javascript](https://developers.facebook.com/docs/javascript)
* Google + Badge - [https://developers.google.com/+/web/badge/](https://developers.google.com/+/web/badge/)
* Twitter RESTful API with Zapier - 

##Typography Resources:

* Typekit - Justmytype.co [justmytype.co/typekit/](http://justmytype.co/typekit/)

##Typography Ideas:

* Publishing
    - Headings, serif, Garamond

##Original Ideas

1. The site should focus on content.  
2. I want to conrol all the templating logic, the content types, the relationships between content, etc *without* having to use external plugins
3. Completely modular&mdash;from sass modules to es6 modules to a removable and customizable search. 
4. I want search to be free, modular (if it doesn't work, I'll throw it out),themeable, and fast. I want it to provide and easy user interface for promoting results, blacklisting and whitelisting content, and for potentitally designing faceted search. 

###Visual Design & Site Architecture

1. Focus on typography.
2. I want to be able to control *every* visual element of the site. I do not want to use themes or purchase layouts. I want to control every element of site architecture. 
2. Resolution-independence for Retina and non-Retina displays
3. Code and syntax highlighting at the aricle level
4. I want to design the site architecture and the relationships in the CMS such that 

###User Experience

1. Responsive design
2. Adaptive design and progressive enhancement (e.g. layout, secondary navigation that changes according to article length)
3. Graceful degradation (for IE9+, although the focus is on IE11, since MS will stop supporting IE10 & IE11 for Windows 7+ in January 2016)
4. Distraction-free reading environment
5. Browser sniffing when necessary for modified mobile experience

##Development 


###Technical Requirements

1. Fast (90+ on Google Page Speed Insights), regardless of site traffic
2. Data that's exportable at *any time*
3. 301 Redirects (no more vanity URLs), including NGINX syntax
4. Video embeds and a video library
5. A forms solution (a basic "Contact Me") that I can style in keeping with the rest of the site.
6. Secure data (i.e., the CMS layer and the data need to be served over http**s**. I don't care about how it's served.)
7. All content data persists in a database.
7. Allow/disallow comments at both the article and site-wide level.  
8. No need for a backend: caching layers, etc. (I don't have time or ability or will to do any of this).
9. No cheating: no libraries, no unsemantic CSS frameworks, no jQuery:)
10. System that's ready for HTTP2.0/SPDY and ES6 AMD


###Publishing & Editorial Requirements

1. Unequivocal ownership/copyright of content
2. I want to write content in markdown in *only* one location
3. I want to be able to create content from desktop, tablet, or *mobile*
4. Save incomplete drafts and ***schedule content***
5. Repurpose content across multiple media according to a content-first publishing model

###Social Media

1. Articles ready for Twitter & Pinterest Cards, Shared Tweets, and Facebook posts--via both a "share this" feature 
2. The ability to allow/disallow a "share-this" style sidebar at both the site and article level.
3. RSS (feed.xml) at the root that is update with every new article

###Analytics

1. User event tracking of topics, sections, or tags.
2. Monthly automated reporting.

###SEO Improvements

1. Page Speed
2. Microformats/microdata (schema.org) for semantic relevance
3. XML Sitemap - includes both a URL listing for Search crawlers and video namespaces for the 'videos' content type


