            {% set tweets = cms.tweet|sort('publish_date', true)|first %}

    <strong>{{ tweets.name }}</strong><br>
    <strong><a href="{{ tweets.tweet_url}}" target="_blank">Here is the tweet</a></strong><br>
    <strong>{{ tweets.tweet_body }}</strong>


    {% for author in authors %}
            <span class="author-name">{{ author.full_name.first }} {{ author.full_name.last }}</span>
            <div class="author-image">
                <img src="{{ author.author_photo|imageCrop(100, 100) }}" />
            </div>
            <div class="author-bio-short">{{ author.short_bio }}</div>
            <ul class="author-social">
                {% if author.github%}
                <li class="github"><a href="{{ author.github }}" target="_blank"></a></li>
                {% endif %} {% if author.twitter %}
                <li class="twitter"><a href="https://www.twitter.com/@{{ author.twitter }}" target="_blank"></a></li>
                {% endif %} {% if author.website %}
                <li class="author-website"><a href="{{ author.website }}"></a></li>
                {% endif %} {% if author.email %}
                <li class="email"><a href="mailto:{{ author.email }}"></a></li>
                {% endif %} {% if author.linkedin %}
                <li class="linkedin"><a href="{{ author.linkedin }}" target="_blank"></a></li>
                {% endif %}
            </ul>
    {% endfor %}


    ORIGINAL ANALYTICS CODE:

    <script async>
          var _gaq=[['_setAccount','{{ getSetting('analytics_id') }}'],['_trackPageview']];
          (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
          g.src='//www.google-analytics.com/ga.js';
          s.parentNode.insertBefore(g,s)}(document,'script'));
        </script>
